def modify(self):
    self.tabWidget.setCurrentIndex(1)
    mydb1 = MySQLdb.connect(host='127.0.0.1',
                            # port=3306,
                            user='root',
                            password='0000',
                            db='policearea')
    a = mydb1.cursor()
    a.execute("SELECT DISTINCT 지방청 from `policearea`.`policearea`")
    result = a.fetchall()
    if result:
        for i in result:
            self.district_office_combobox.addItem(str(i[0]))