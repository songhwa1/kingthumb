from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
import sys
from PyQt5.uic import loadUiType
from PyQt5 import uic
import MySQLdb


form_class = uic.loadUiType("school.ui")[0]

class Main(QMainWindow, form_class):
    def __init__(self):
        QMainWindow.__init__(self)
        self.setupUi(self)
        # 데이터 베이스 연결, 여기서 con은 디비에 연결 하려는 가지고 있는 변수이다.
        # 데이터를 수집하기 위해 커서 객체를 생성 해야 한다.
        self.mydb = MySQLdb.connect(host="127.0.0.1", user="root", password="0000", db="school")
        self.curs = self.mydb.cursor()
        self.tabWidget.setCurrentIndex(0)
        self.tabWidget.tabBar().setVisible(False)
        self.menubar.setVisible(False)
        self.professor_login_btn.clicked.connect(self.login)
        self.student_information_save_btn.clicked.connect(self.save_student_details)

        self.ad_student.triggered.connect(self.add_student)

    def login(self):
        pi = self.professor_id.text()
        pw = self.professor_password.text()

        if(pi=="admin" and pw =="admin"):
            msg = QMessageBox()
            msg.setWindowTitle("광주인력개발원")
            msg.setText("로그인되었습니다. 환영합니다.")
            msg.setIcon(QMessageBox.Information)
            msg.exec_()
            self.menubar.setVisible(True)
            self.tabWidget.setCurrentIndex(1)
        else:
            msg = QMessageBox()
            msg.setWindowTitle("광주인력개발원")
            msg.setText("회원정보가 일치하지 않습니다.")
            msg.setIcon(QMessageBox.Critical)
            msg.exec_()

    def add_student(self):
        self.tabWidget.setCurrentIndex(2)

    def save_student_details(self):
        curriculum = self.curriculum_combobox.currentText()
        registration_number = self.registration_number.text()
        name = self.student_name.text()
        gender = self.student_gender_combobox.currentText()
        birth = self.student_birth.text()
        age = self.student_age.text()
        address = self.student_address.text()
        phone = self.student_phone.text()
        email = self.student_email.text()

        self.curs.execute(
            "insert into school.student (curriculum,registration_number,name,gender,birth,age,address,phone,email)values('"+str(curriculum)+"','"+str(registration_number)+"', '"+str(name)+"', '"+str(gender)+"', '"+str(birth)+"', '"+str(int(age))+"', '"+str(address)+"', '"+str(phone)+"', '"+str(email)+"' )")
        self.mydb.commit()
        msg = QMessageBox()
        msg.setWindowTitle("광주인력개발원")
        msg.setText("학생정보가 정상적으로 등록되었습니다.")
        msg.setIcon(QMessageBox.Information)
        msg.exec_()
        # self.curs.execute("select * from school.student")
        # result = self.curs.fetchall()
        # if result:
        #     for i in result:




def main():
    app = QApplication(sys.argv)
    window = Main()
    window.show()
    app.exec_()

if __name__ == '__main__':
    main()